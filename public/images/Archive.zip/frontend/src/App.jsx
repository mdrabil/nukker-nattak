import { useState } from 'react';
import { Sparkles, Zap, CheckCircle2, FileText, Award, Cpu, Lock } from 'lucide-react';
import './index.css';

const plans = [
    {
        id: 'free',
        name: 'Starter',
        desc: 'Perfect for new RAs with up to 25 clients.',
        price: 0,
        features: [
            { text: '0-25 Clients', ai: false },
            { text: 'Basic Performance Analytics', ai: false },
            { text: 'Client Portal Push', ai: false },
            { text: 'Smart Compliance Check', ai: true }
        ]
    },
    {
        id: 'pro',
        name: 'Pro AI',
        desc: 'For growing businesses needing dispatch automation.',
        price: 6250,
        features: [
            { text: 'Up to 50 Clients', ai: false },
            { text: 'WhatsApp & Telegram Dispatch', ai: false },
            { text: 'AI Research Report Generator', ai: true },
            { text: 'Automated Universe Builder', ai: true }
        ]
    },
    {
        id: 'enterprise',
        name: 'Enterprise',
        desc: 'Unlimited scale with custom AI agents and APIs.',
        price: 49999,
        features: [
            { text: '76+ Clients (Unlimited)', ai: false },
            { text: 'Custom API & Webhooks', ai: false },
            { text: 'Dedicated Support Agent', ai: false },
            { text: 'Predictive Strategy Analytics', ai: true }
        ]
    }
];

function App() {
    const [selectedPlan, setSelectedPlan] = useState('pro');
    const [billing, setBilling] = useState('monthly');

    const getActivePlan = () => plans.find(p => p.id === selectedPlan);
    
    const calculateTotal = () => {
        const plan = getActivePlan();
        let cost = plan.price;
        if (billing === 'annual') {
            cost = (cost * 10);
        }
        return cost.toLocaleString('en-IN');
    };

    const getSetupFee = () => {
        if (selectedPlan === 'free') return '₹0';
        return billing === 'annual' ? 'Waived' : '₹15,000';
    };

    return (
        <>
            <div className="aura-1"></div>
            <div className="aura-2"></div>
            <div className="container">
                {/* Hero */}
                <div className="hero">
                    <div className="ai-badge">
                        <Sparkles size={16} /> Powered by MoneyBells Intelligence
                    </div>
                    <h1>Supercharge Your Advisory<br/><span>with AI-Driven Operations</span></h1>
                    <p>Join the next generation of SEBI-registered Research Analysts. Automate compliance, dispatch signals instantly, and generate insights with our AI workspace.</p>
                </div>

                {/* Pricing Cards */}
                <div className="pricing-section">
                    <div style={{display: 'flex', justifyContent: 'center', marginBottom: '3rem'}}>
                        <div style={{background: 'rgba(255,255,255,0.8)', padding: '6px', borderRadius: '30px', display: 'flex', gap: '8px', border: '1px solid var(--glass-border)', boxShadow: 'var(--shadow-glass)'}}>
                            <button 
                                onClick={() => setBilling('monthly')}
                                style={{padding: '10px 24px', border: 'none', borderRadius: '24px', background: billing === 'monthly' ? '#fff' : 'transparent', color: billing === 'monthly' ? '#0F172A' : '#64748B', fontWeight: 600, cursor: 'pointer', boxShadow: billing === 'monthly' ? '0 2px 10px rgba(0,0,0,0.05)' : 'none', transition: 'all 0.3s'}}
                            >
                                Monthly
                            </button>
                            <button 
                                onClick={() => setBilling('annual')}
                                style={{padding: '10px 24px', border: 'none', borderRadius: '24px', background: billing === 'annual' ? '#fff' : 'transparent', color: billing === 'annual' ? '#0F172A' : '#64748B', fontWeight: 600, cursor: 'pointer', boxShadow: billing === 'annual' ? '0 2px 10px rgba(0,0,0,0.05)' : 'none', transition: 'all 0.3s', display: 'flex', alignItems: 'center', gap: '8px'}}
                            >
                                Annual <span style={{background: 'var(--ai-glow)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', fontSize: '0.8rem'}}>2 Months Free</span>
                            </button>
                        </div>
                    </div>

                    <div className="pricing-grid">
                        {plans.map(plan => (
                            <div 
                                key={plan.id} 
                                className={`plan-card ${selectedPlan === plan.id ? 'selected' : ''}`}
                                onClick={() => setSelectedPlan(plan.id)}
                            >
                                <div className="plan-name">{plan.name}</div>
                                <div className="plan-desc">{plan.desc}</div>
                                <div className="plan-price">
                                    ₹{billing === 'annual' && plan.price > 0 ? (plan.price * 10).toLocaleString('en-IN') : plan.price.toLocaleString('en-IN')}
                                    <span>/{billing === 'annual' && plan.price > 0 ? 'yr' : 'mo'}</span>
                                </div>
                                <ul className="feature-list">
                                    {plan.features.map((feat, idx) => (
                                        <li key={idx} className={feat.ai ? 'ai-feature' : ''}>
                                            {feat.ai ? (
                                                <Zap size={18} color="#8B5CF6" />
                                            ) : (
                                                <CheckCircle2 size={18} color="#10B981" />
                                            )}
                                            {feat.text}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Smart Setup Form */}
                <div className="setup-section">
                    <div className="glass-panel">
                        <h2 className="panel-title">Smart Setup Wizard</h2>
                        <p className="panel-subtitle">Provide your registration details. Our AI will automatically verify your SEBI credentials against public records.</p>
                        
                        <form className="form-grid">
                            <div className="input-group">
                                <label>Full Name as per PAN</label>
                                <input type="text" className="smart-input" placeholder="e.g. Rahul Sharma" />
                            </div>
                            <div className="input-group">
                                <label>Brand Name</label>
                                <input type="text" className="smart-input" placeholder="e.g. Wealth Advisors" />
                            </div>
                            
                            <div className="input-group full-width">
                                <label>Custom Workspace Domain</label>
                                <div style={{display: 'flex', gap: '12px'}}>
                                    <input type="text" className="smart-input" placeholder="brandname" style={{flex: 1}} />
                                    <div style={{padding: '14px 16px', background: 'rgba(0,0,0,0.05)', borderRadius: '12px', color: '#64748B', fontWeight: 500}}>
                                        .ra.moneybells.in
                                    </div>
                                </div>
                            </div>

                            <div className="input-group">
                                <label>Email Address</label>
                                <input type="email" className="smart-input" placeholder="Secure OTP will be sent here" />
                            </div>
                            <div className="input-group">
                                <label>SEBI Registration No.</label>
                                <input type="text" className="smart-input" placeholder="e.g. INH000000000" />
                            </div>

                            <div className="input-group full-width" style={{marginTop: '1rem'}}>
                                <label>Upload Documents (AI Verification)</label>
                                <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem'}}>
                                    <div className="file-upload">
                                        <FileText size={32} color="#6366F1" style={{margin: '0 auto'}} />
                                        <p>Drop PAN Card PDF</p>
                                    </div>
                                    <div className="file-upload">
                                        <Award size={32} color="#6366F1" style={{margin: '0 auto'}} />
                                        <p>Drop SEBI Certificate</p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    {/* Live Estimator Sidebar */}
                    <div className="glass-panel estimator-panel">
                        <div className="estimator-header">
                            <div className="estimator-icon">
                                <Cpu size={20} />
                            </div>
                            <div>
                                <h3 style={{fontSize: '1.2rem', marginBottom: '2px'}}>Cost Estimator</h3>
                                <p style={{fontSize: '0.85rem', color: 'var(--text-muted)'}}>Live AI Computation</p>
                            </div>
                        </div>

                        <div className="cost-row">
                            <span style={{color: 'var(--text-muted)'}}>Selected Plan</span>
                            <strong>{getActivePlan().name}</strong>
                        </div>
                        <div className="cost-row">
                            <span style={{color: 'var(--text-muted)'}}>Billing Term</span>
                            <strong style={{textTransform: 'capitalize'}}>{billing}</strong>
                        </div>
                        <div className="cost-row">
                            <span style={{color: 'var(--text-muted)'}}>Setup Fee</span>
                            <strong style={{color: billing === 'annual' ? '#10B981' : '#0F172A'}}>{getSetupFee()}</strong>
                        </div>
                        <div className="cost-row">
                            <span style={{color: 'var(--text-muted)'}}>AI Verification</span>
                            <strong style={{color: '#10B981'}}>Included</strong>
                        </div>

                        <div className="cost-row total">
                            <span>Total Due Today</span>
                            <span style={{background: 'var(--ai-glow)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
                                ₹{calculateTotal()}
                            </span>
                        </div>

                        <button className="btn-gradient">
                            <Lock size={18} />
                            Secure Checkout
                        </button>
                        <p style={{textAlign: 'center', fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '1rem'}}>
                            Protected by Cashfree & MoneyBells Security
                        </p>
                    </div>
                </div>
            </div>
        </>
    );
}

export default App;
