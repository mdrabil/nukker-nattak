import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Dummy Auth Endpoint
app.post('/api/auth/login', (req, res) => {
    const { email, password, role } = req.body;

    // Simulate basic validation
    if (!email || !password || !role) {
        return res.status(400).json({ message: 'Missing credentials' });
    }

    // Mock successful authentication
    const token = jwt.sign(
        { email, role },
        process.env.JWT_SECRET || 'fallback_secret',
        { expiresIn: '1h' }
    );

    res.json({
        success: true,
        token,
        user: { email, role }
    });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'OK', message: 'MoneyBells CRM API is running' });
});

app.listen(PORT, () => {
    console.log(`MoneyBells Backend Server running on port ${PORT}`);
});
